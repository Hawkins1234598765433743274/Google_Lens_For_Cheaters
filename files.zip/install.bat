@echo off
setlocal EnableDelayedExpansion
title MathLens Installer
color 0B

echo.
echo  ============================================
echo    MathLens Installer
echo    Math OCR + Step-by-Step Solver
echo  ============================================
echo.

:: ── Check for Python ──────────────────────────────────────────────────────
echo [1/5] Checking for Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [!] Python not found!
    echo      Please install Python 3.9+ from https://www.python.org/downloads/
    echo      Make sure to check "Add Python to PATH" during install.
    echo.
    pause
    start https://www.python.org/downloads/
    exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo     Found Python %PYVER%

:: ── Upgrade pip ───────────────────────────────────────────────────────────
echo.
echo [2/5] Upgrading pip...
python -m pip install --upgrade pip --quiet
if errorlevel 1 (
    echo  [!] Failed to upgrade pip. Continuing anyway...
)

:: ── Install dependencies ──────────────────────────────────────────────────
echo.
echo [3/5] Installing dependencies (this may take a minute)...
echo.

set PACKAGES=openai pillow pyperclip keyboard

for %%p in (%PACKAGES%) do (
    echo      Installing %%p...
    python -m pip install %%p --quiet
    if errorlevel 1 (
        echo  [!] Failed to install %%p. Please run as Administrator or check your internet connection.
        pause
        exit /b 1
    )
)
echo.
echo     All dependencies installed successfully!

:: ── Create startup shortcut ───────────────────────────────────────────────
echo.
echo [4/5] Creating startup shortcut...

set SCRIPT_DIR=%~dp0
set SHORTCUT_PATH=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\MathLens.lnk
set PYTHONW=%LOCALAPPDATA%\Programs\Python\Python3*\pythonw.exe

:: Use PowerShell to create shortcut
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; ^
   $s = $ws.CreateShortcut('%SHORTCUT_PATH%'); ^
   $s.TargetPath = 'pythonw'; ^
   $s.Arguments = '\"%SCRIPT_DIR%mathlens.py\"'; ^
   $s.WorkingDirectory = '%SCRIPT_DIR%'; ^
   $s.Description = 'MathLens - Math OCR Solver'; ^
   $s.Save()" >nul 2>&1

if exist "%SHORTCUT_PATH%" (
    echo     Startup shortcut created — MathLens will launch with Windows.
) else (
    echo     [!] Could not create startup shortcut. You can launch mathlens.py manually.
)

:: ── API Key setup info ────────────────────────────────────────────────────
echo.
echo [5/5] API Key Setup...
echo.
echo  MathLens uses the OpenRouter API to solve math problems.
echo  You will need a FREE API key from OpenRouter.
echo.
echo  Steps to get your key:
echo    1. Go to  https://openrouter.ai/keys
echo    2. Sign up for a free account
echo    3. Go to "API Keys" and create a new key
echo    4. Paste it when MathLens asks on first launch
echo.

set /p OPEN_BROWSER="  Open Anthropic Console in browser now? (Y/N): "
if /i "%OPEN_BROWSER%"=="Y" (
    start https://openrouter.ai/keys
)

:: ── Launch MathLens ───────────────────────────────────────────────────────
echo.
echo  ============================================
echo    Installation complete!
echo.
echo    MathLens Hotkey:  Ctrl + Shift + L
echo    - Draw a box around any math problem
echo    - Get instant answer + step-by-step solution
echo    - Answer is auto-copied to clipboard
echo.
echo    MathLens will now launch for first-time setup.
echo  ============================================
echo.
pause

start "" pythonw "%SCRIPT_DIR%mathlens.py"
exit /b 0
