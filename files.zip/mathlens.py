import sys
import os
import json
import base64
import threading
import tkinter as tk
import pyperclip
from PIL import ImageGrab, ImageTk, Image
import keyboard
from openai import OpenAI  # openrouter is openai-compatible
from io import BytesIO

CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")

ROOT = None
_capture_active = False  # debounce flag to prevent double-trigger

# ── Config ────────────────────────────────────────────────────────────────────

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    return {}

def save_config(data):
    with open(CONFIG_FILE, "w") as f:
        json.dump(data, f)

def get_api_key():
    cfg = load_config()
    return cfg.get("api_key", "").strip() or None

def reset_api_key():
    save_config({"api_key": ""})

# ── API key prompt ────────────────────────────────────────────────────────────

def show_api_key_prompt(on_done):
    win = tk.Toplevel(ROOT)
    win.title("MathLens — Setup")
    win.resizable(False, False)
    win.configure(bg="#0f0f0f")
    win.attributes("-topmost", True)
    win.grab_set()
    center_window(win, 540, 360)

    tk.Label(win, text="MathLens Setup", font=("Segoe UI", 16, "bold"),
             bg="#0f0f0f", fg="#ffffff").pack(pady=(28, 6))
    tk.Label(win,
             text="Enter your OpenRouter API key below.\nGet one free at openrouter.ai/keys",
             font=("Segoe UI", 10), bg="#0f0f0f", fg="#aaaaaa", justify="center").pack(pady=(0, 18))

    entry_var = tk.StringVar()
    entry = tk.Entry(win, textvariable=entry_var, font=("Consolas", 11),
                     bg="#1e1e1e", fg="#ffffff", insertbackground="#ffffff",
                     relief="flat", width=46)
    entry.pack(ipady=8, padx=40)
    entry.focus_set()

    tk.Label(win, text="Key shown so you can verify it's correct before saving.",
             font=("Segoe UI", 8), bg="#0f0f0f", fg="#555555").pack(pady=(4, 0))

    msg = tk.Label(win, text="", font=("Segoe UI", 9), bg="#0f0f0f", fg="#ff5f5f")
    msg.pack(pady=4)

    def on_save():
        key = entry_var.get().strip()
        if len(key) < 10:
            msg.config(text="Key looks too short — double-check and try again.")
            return
        save_config({"api_key": key})
        win.destroy()
        on_done(key)

    entry.bind("<Return>", lambda e: on_save())
    tk.Button(win, text="Save & Continue", command=on_save,
              font=("Segoe UI", 11, "bold"), bg="#4f8ef7", fg="#ffffff",
              relief="flat", cursor="hand2", padx=20, pady=8).pack(pady=12)
    tk.Label(win, text="Your key is stored locally only — never shared.",
             font=("Segoe UI", 8), bg="#0f0f0f", fg="#555555").pack()

    win.protocol("WM_DELETE_WINDOW", lambda: ROOT.destroy())

# ── Loading popup ─────────────────────────────────────────────────────────────

def show_loading():
    win = tk.Toplevel(ROOT)
    win.title("MathLens")
    win.configure(bg="#0f0f0f")
    win.attributes("-topmost", True)
    win.overrideredirect(True)
    center_window(win, 320, 90)
    tk.Label(win, text="Solving your math problem...",
             font=("Segoe UI", 11), bg="#0f0f0f", fg="#aaaaaa").pack(expand=True)
    win.update()
    return win

# ── Screenshot selector ───────────────────────────────────────────────────────

class ScreenshotSelector:
    def __init__(self, on_selected):
        self.on_selected = on_selected
        self.win = tk.Toplevel(ROOT)
        self.win.attributes("-fullscreen", True)
        self.win.attributes("-alpha", 0.25)
        self.win.attributes("-topmost", True)
        self.win.configure(bg="black", cursor="crosshair")
        self.win.overrideredirect(True)

        self.canvas = tk.Canvas(self.win, bg="black", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        self.start_x = self.start_y = 0
        self.rect = None

        self.canvas.bind("<ButtonPress-1>", self.on_press)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.win.bind("<Escape>", lambda e: self._cancel())

    def _cancel(self):
        global _capture_active
        _capture_active = False
        self.win.destroy()

    def on_press(self, event):
        self.start_x, self.start_y = event.x, event.y

    def on_drag(self, event):
        if self.rect:
            self.canvas.delete(self.rect)
        self.rect = self.canvas.create_rectangle(
            self.start_x, self.start_y, event.x, event.y,
            outline="#4f8ef7", width=2, fill="#4f8ef7", stipple="gray25"
        )

    def on_release(self, event):
        x1 = min(self.start_x, event.x)
        y1 = min(self.start_y, event.y)
        x2 = max(self.start_x, event.x)
        y2 = max(self.start_y, event.y)
        self.win.destroy()
        if x2 - x1 > 10 and y2 - y1 > 10:
            self.on_selected(x1, y1, x2, y2)
        else:
            global _capture_active
            _capture_active = False

# ── Result popup ──────────────────────────────────────────────────────────────

def show_result(answer, steps, img_pil, api_key):
    win = tk.Toplevel(ROOT)
    win.title("MathLens")
    win.configure(bg="#0f0f0f")
    win.attributes("-topmost", True)
    win.resizable(True, True)
    center_window(win, 520, 620)

    # Header
    hdr = tk.Frame(win, bg="#0f0f0f")
    hdr.pack(fill="x", padx=20, pady=(18, 0))
    tk.Label(hdr, text="MathLens", font=("Segoe UI", 13, "bold"),
             bg="#0f0f0f", fg="#4f8ef7").pack(side="left")
    tk.Button(hdr, text="X", command=win.destroy,
              font=("Segoe UI", 11), bg="#0f0f0f", fg="#666666",
              relief="flat", cursor="hand2", bd=0).pack(side="right")

    # Thumbnail
    if img_pil:
        thumb = img_pil.copy()
        thumb.thumbnail((480, 160), Image.LANCZOS)
        photo = ImageTk.PhotoImage(thumb)
        img_frame = tk.Frame(win, bg="#1a1a1a")
        img_frame.pack(fill="x", padx=20, pady=(12, 0))
        lbl = tk.Label(img_frame, image=photo, bg="#1a1a1a")
        lbl.pack(pady=6)
        lbl.image = photo

    # Answer box
    ans_frame = tk.Frame(win, bg="#1a2a3a")
    ans_frame.pack(fill="x", padx=20, pady=(14, 0))
    tk.Label(ans_frame, text="ANSWER", font=("Segoe UI", 8, "bold"),
             bg="#1a2a3a", fg="#4f8ef7").pack(anchor="w", padx=14, pady=(10, 0))
    tk.Label(ans_frame, text=answer, font=("Consolas", 18, "bold"),
             bg="#1a2a3a", fg="#ffffff", wraplength=460, justify="left").pack(
                 anchor="w", padx=14, pady=(2, 10))

    btn_row = tk.Frame(win, bg="#0f0f0f")
    btn_row.pack(anchor="w", padx=20, pady=(10, 0))

    # Copy button
    def copy_answer():
        pyperclip.copy(answer)
        copy_btn.config(text="Copied!")
        win.after(1800, lambda: copy_btn.config(text="Copy Answer"))

    copy_btn = tk.Button(btn_row, text="Copy Answer", command=copy_answer,
                         font=("Segoe UI", 10, "bold"), bg="#4f8ef7", fg="#ffffff",
                         relief="flat", cursor="hand2", padx=16, pady=7)
    copy_btn.pack(side="left", padx=(0, 8))

    # Reset key button always visible
    def reset_and_reprompt():
        reset_api_key()
        win.destroy()
        show_api_key_prompt(on_done=lambda new_key: restart_hotkey(new_key))

    tk.Button(btn_row, text="Change API Key", command=reset_and_reprompt,
              font=("Segoe UI", 10), bg="#333333", fg="#aaaaaa",
              relief="flat", cursor="hand2", padx=12, pady=7).pack(side="left")

    # Auto-copy on open
    pyperclip.copy(answer)

    # Steps
    tk.Label(win, text="STEP-BY-STEP SOLUTION",
             font=("Segoe UI", 8, "bold"), bg="#0f0f0f", fg="#888888").pack(
                 anchor="w", padx=20, pady=(18, 4))

    scroll_frame = tk.Frame(win, bg="#0f0f0f")
    scroll_frame.pack(fill="both", expand=True, padx=20, pady=(0, 16))

    scrollbar = tk.Scrollbar(scroll_frame)
    scrollbar.pack(side="right", fill="y")

    text_box = tk.Text(scroll_frame, font=("Segoe UI", 10), bg="#141414",
                       fg="#dddddd", relief="flat", wrap="word",
                       yscrollcommand=scrollbar.set, padx=12, pady=10,
                       spacing2=4, spacing3=6)
    text_box.pack(fill="both", expand=True)
    scrollbar.config(command=text_box.yview)
    text_box.insert("end", steps)
    text_box.config(state="disabled")

    return win

# ── Math solver (OpenRouter, background thread) ───────────────────────────────

def image_to_base64(img: Image.Image) -> str:
    buf = BytesIO()
    img.save(buf, format="PNG")
    return base64.standard_b64encode(buf.getvalue()).decode("utf-8")

def solve_math(api_key: str, img: Image.Image):
    client = OpenAI(
        api_key=api_key,
        base_url="https://openrouter.ai/api/v1",
    )
    b64 = image_to_base64(img)

    prompt = (
        "You are a math tutor. The user has captured an image containing a math problem.\n\n"
        "1. Identify the math problem in the image.\n"
        "2. Solve it completely.\n"
        "3. Reply in this EXACT format (no extra text before or after):\n\n"
        "ANSWER: <just the final numerical or algebraic answer>\n\n"
        "STEPS:\n"
        "<clear step-by-step explanation, one step per line, numbered>"
    )

    response = client.chat.completions.create(
        model="anthropic/claude-opus-4-5",
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": [
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
                {"type": "text", "text": prompt}
            ]
        }]
    )

    raw = response.choices[0].message.content.strip()
    answer = "Could not parse answer"
    steps = raw

    if "ANSWER:" in raw:
        parts = raw.split("ANSWER:", 1)[1]
        if "STEPS:" in parts:
            answer_part, steps_part = parts.split("STEPS:", 1)
            answer = answer_part.strip()
            steps = steps_part.strip()
        else:
            answer = parts.strip()

    return answer, steps

# ── Capture flow ──────────────────────────────────────────────────────────────

def do_capture(api_key):
    global _capture_active
    if _capture_active:
        return  # already open, ignore
    _capture_active = True

    def on_region_selected(x1, y1, x2, y2):
        global _capture_active
        img = ImageGrab.grab(bbox=(x1, y1, x2, y2))
        loading_win = show_loading()

        def solve_in_bg():
            try:
                answer, steps = solve_math(api_key, img)
            except Exception as e:
                err = str(e)
                answer = "Error"
                steps = (
                    f"Something went wrong:\n\n{err}\n\n"
                    "If this is an auth error, use 'Change API Key' to re-enter your key."
                )
            ROOT.after(0, lambda: finish(answer, steps, img, loading_win, api_key))

        threading.Thread(target=solve_in_bg, daemon=True).start()

    ScreenshotSelector(on_region_selected)

def finish(answer, steps, img_pil, loading_win, api_key):
    global _capture_active
    _capture_active = False
    try:
        loading_win.destroy()
    except Exception:
        pass
    show_result(answer, steps, img_pil, api_key)

# ── Hotkey ────────────────────────────────────────────────────────────────────

def on_hotkey(api_key):
    ROOT.after(0, lambda: do_capture(api_key))

def restart_hotkey(new_key):
    keyboard.unhook_all()
    keyboard.add_hotkey("ctrl+shift+l", lambda: on_hotkey(new_key))

# ── Helpers ───────────────────────────────────────────────────────────────────

def center_window(win, w, h):
    sw = win.winfo_screenwidth()
    sh = win.winfo_screenheight()
    x = (sw - w) // 2
    y = (sh - h) // 2
    win.geometry(f"{w}x{h}+{x}+{y}")

# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    global ROOT
    ROOT = tk.Tk()
    ROOT.withdraw()

    def start_with_key(api_key):
        keyboard.add_hotkey("ctrl+shift+l", lambda: on_hotkey(api_key))
        print("MathLens running. Press Ctrl+Shift+L to capture. Close this window to quit.")

    api_key = get_api_key()
    if api_key:
        start_with_key(api_key)
    else:
        show_api_key_prompt(on_done=start_with_key)

    ROOT.mainloop()

if __name__ == "__main__":
    main()
